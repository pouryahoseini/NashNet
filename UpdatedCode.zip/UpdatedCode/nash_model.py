import numpy as np
import csv


def GetTrainingDatafromCSV(file):
    traindata = []
    groundtruth = []
    with open(file) as csvfile:
        readCSV = csv.reader(csvfile, delimiter=',')
        next(readCSV)
        for row in readCSV:
            traindata.append(row[1])
            groundtruth.append(row[2])
    traindata = np.asarray(traindata)
    groundtruth = np.asarray(groundtruth)
    return traindata,groundtruth